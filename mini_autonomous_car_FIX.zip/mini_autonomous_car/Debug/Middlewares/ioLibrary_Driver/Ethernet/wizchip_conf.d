Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.o: \
 ../Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.c \
 ../Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.h \
 ../Middlewares/ioLibrary_Driver/Ethernet/W5500/w5500.h \
 D:/kuliah/its/iris25/Mini\ Autonomous\ Car/driver_1/mini_autonomous_car/Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.h
../Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.h:
../Middlewares/ioLibrary_Driver/Ethernet/W5500/w5500.h:
D:/kuliah/its/iris25/Mini\ Autonomous\ Car/driver_1/mini_autonomous_car/Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.h:
