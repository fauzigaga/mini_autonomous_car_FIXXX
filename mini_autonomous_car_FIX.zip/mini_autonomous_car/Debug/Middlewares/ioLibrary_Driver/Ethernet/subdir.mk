################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Middlewares/ioLibrary_Driver/Ethernet/socket.c \
../Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.c 

OBJS += \
./Middlewares/ioLibrary_Driver/Ethernet/socket.o \
./Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.o 

C_DEPS += \
./Middlewares/ioLibrary_Driver/Ethernet/socket.d \
./Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.d 


# Each subdirectory must supply rules for building sources it contributes
Middlewares/ioLibrary_Driver/Ethernet/%.o Middlewares/ioLibrary_Driver/Ethernet/%.su Middlewares/ioLibrary_Driver/Ethernet/%.cyclo: ../Middlewares/ioLibrary_Driver/Ethernet/%.c Middlewares/ioLibrary_Driver/Ethernet/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G473xx -c -I../Core/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -I"D:/kuliah/its/iris25/Mini Autonomous Car/driver_1/mini_autonomous_car/Middlewares/ioLibrary_Driver/Ethernet/W5500" -I"D:/kuliah/its/iris25/Mini Autonomous Car/driver_1/mini_autonomous_car/Middlewares/ioLibrary_Driver/Ethernet" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Middlewares-2f-ioLibrary_Driver-2f-Ethernet

clean-Middlewares-2f-ioLibrary_Driver-2f-Ethernet:
	-$(RM) ./Middlewares/ioLibrary_Driver/Ethernet/socket.cyclo ./Middlewares/ioLibrary_Driver/Ethernet/socket.d ./Middlewares/ioLibrary_Driver/Ethernet/socket.o ./Middlewares/ioLibrary_Driver/Ethernet/socket.su ./Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.cyclo ./Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.d ./Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.o ./Middlewares/ioLibrary_Driver/Ethernet/wizchip_conf.su

.PHONY: clean-Middlewares-2f-ioLibrary_Driver-2f-Ethernet

