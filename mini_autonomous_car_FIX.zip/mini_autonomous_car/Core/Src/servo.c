/*
 * servo.c
 *
 *  Created on: Oct 13, 2026
 *      Author: user
 */

#include "servo.h"
#include <stdint.h>
#include "tim.h"
void PWM_Init(void);
void PWM_SetServo(int16_t pwmServo)
{
    if (pwmServo < 1) pwmServo = 1;
    if (pwmServo > 200) pwmServo = 200;
    int16_t pwmValue = 1790 + (pwmServo - 1);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, pwmValue);
}
