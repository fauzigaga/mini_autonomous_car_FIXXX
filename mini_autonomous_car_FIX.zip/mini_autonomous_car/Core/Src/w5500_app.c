#include "w5500_app.h"
#include "wizchip_conf.h"
#include "socket.h"
#include "string.h"

extern SPI_HandleTypeDef hspi1;

/* Konfigurasi Jaringan (Peer-to-Peer ke Laptop 192.168.3.101) */
static wiz_NetInfo net_info = {
    .mac  = { 0x00, 0x08, 0xDC, 0x12, 0x34, 0x56 },
    .ip   = { 192, 168, 3, 100 },  // IP STM32
    .sn   = { 255, 255, 255, 0 },  // Subnet mask
    .gw   = { 192, 168, 3, 101 },  // Gateway = IP Laptop
    .dns  = { 8, 8, 8, 8 },
    .dhcp = NETINFO_STATIC
};

#define DEST_IP       { 192, 168, 3, 101 } // IP Laptop
#define DEST_PORT     5005                 // Port Tujuan UDP di Laptop (Diubah dari 5000 ke 5005)
#define LOCAL_PORT    4000                 // Port Sumber/Pengirim dari STM32
#define SOCKET_NUM    0                    // Socket 0 untuk Transmit (TX)
#define SOCKET_NUM_RX 1                    // Socket 1 untuk Receive (RX)
#define LOCAL_PORT_RX 49153                // Port Listening untuk Terima Data di STM32

/* ── Callback CS ── */
static void cs_low(void) {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
}
static void cs_high(void) {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);
}

/* ── Callback SPI (Full-Duplex Safe) ── */
static uint8_t spi_read_byte(void) {
    uint8_t rx_data = 0;
    uint8_t dummy = 0xFF;
    HAL_SPI_TransmitReceive(&hspi1, &dummy, &rx_data, 1, HAL_MAX_DELAY);
    return rx_data;
}

static void spi_write_byte(uint8_t data) {
    uint8_t dummy = 0;
    HAL_SPI_TransmitReceive(&hspi1, &data, &dummy, 1, HAL_MAX_DELAY);
}

static void spi_read_burst(uint8_t *buf, uint16_t len) {
    for (uint16_t i = 0; i < len; i++) {
        buf[i] = spi_read_byte();
    }
}

static void spi_write_burst(uint8_t *buf, uint16_t len) {
    HAL_SPI_Transmit(&hspi1, buf, len, HAL_MAX_DELAY);
}

void W5500_Init(void) {
    /* Reset hardware W5500 */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
    HAL_Delay(50);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
    HAL_Delay(100);

    reg_wizchip_cs_cbfunc(cs_low, cs_high);
    reg_wizchip_spi_cbfunc(spi_read_byte, spi_write_byte);
    reg_wizchip_spiburst_cbfunc(spi_read_burst, spi_write_burst);

    uint8_t memsize[2][8] = {{ 2, 2, 2, 2, 2, 2, 2, 2 }, { 2, 2, 2, 2, 2, 2, 2, 2 }};
    wizchip_init(memsize[0], memsize[1]);

    wizchip_setnetinfo(&net_info);
}

void W5500_UDP_Receive(uint8_t *data, uint16_t len) {
    uint8_t src_ip[4];
    uint16_t src_port;

    if (getSn_SR(SOCKET_NUM_RX) != SOCK_UDP) {
        socket(SOCKET_NUM_RX, Sn_MR_UDP, LOCAL_PORT_RX, 0);
    }

    uint16_t size = getSn_RX_RSR(SOCKET_NUM_RX);
    if (size > 0) {
        if (size > len) size = len;
        recvfrom(SOCKET_NUM_RX, data, size, src_ip, &src_port);
    }
}

void W5500_UDP_Send(uint8_t *data, uint16_t len) {
    uint8_t dest_ip[] = DEST_IP;

    if (getSn_SR(SOCKET_NUM) != SOCK_UDP) {
        socket(SOCKET_NUM, Sn_MR_UDP, LOCAL_PORT, 0);
    }

    sendto(SOCKET_NUM, data, len, dest_ip, DEST_PORT);
}
