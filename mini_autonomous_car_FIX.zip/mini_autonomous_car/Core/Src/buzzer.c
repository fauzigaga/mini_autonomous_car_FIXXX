/*
 * buzzer.c
 *
 *  Created on: Oct 13, 2026
 *      Author: user
 */

#include "buzzer.h"

void Buzzer_Init(void)
{
    HAL_GPIO_WritePin(BUZZER_PORT, BUZZER_PIN, GPIO_PIN_RESET);
}

void Buzzer_On(void)
{
    HAL_GPIO_WritePin(BUZZER_PORT, BUZZER_PIN, GPIO_PIN_SET);
}

void Buzzer_Off(void)
{
    HAL_GPIO_WritePin(BUZZER_PORT, BUZZER_PIN, GPIO_PIN_RESET);
}

void Buzzer_Toggle(void)
{
    HAL_GPIO_TogglePin(BUZZER_PORT, BUZZER_PIN);
}

// Bunyi beep singkat
void Buzzer_Beep(uint16_t delay_ms)
{
    Buzzer_On();
    HAL_Delay(delay_ms);
    Buzzer_Off();
}
