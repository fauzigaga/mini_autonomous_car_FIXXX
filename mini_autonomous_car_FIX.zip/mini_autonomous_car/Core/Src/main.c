/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body (Master Board dengan W5500 & CAN)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "fdcan.h"
#include "spi.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "w5500_app.h"
#include "string.h"
#include "buzzer.h"
#include "servo.h"

/* USER CODE BEGIN PV */
uint8_t rx_buf[30];
uint8_t udp_buf[30];
char header[4] = { "its" };

int16_t speed = 0;
int16_t speed1 = 0;      /* Diterima dari PC via UDP */
int16_t enable = 0;      /* Diterima dari PC via UDP (1 Byte) */
int16_t encoder = 0;     /* Data 1 dari Slave Motor Driver */
int16_t current = 0;     /* Data 2 dari Slave Motor Driver */
int16_t pwmServo = 0;    /* Diterima dari PC via UDP */
int8_t button1 = 0;
int8_t button2 = 0;
int16_t adc_raw = 0;
float voltage = 0;
uint16_t voltage_mV = 0;

uint8_t driver_tx_data[8] = {0};
static uint8_t node_id_motor = 4; // Target Node ID Slave Motor Driver

volatile uint8_t my_node_id = 1;
volatile uint8_t sync_active = 0;
volatile uint8_t save_node_req = 0;

FDCAN_TxHeaderTypeDef txHeader1;
FDCAN_TxHeaderTypeDef txHeader2;

static uint8_t txData[8] = {0};

volatile uint32_t last_btn1_tick = 0;
volatile uint32_t last_btn2_tick = 0;
/* USER CODE END PV */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* DS 301 */
#define COB_ID_SDO_REQUEST   0x600
#define COB_ID_SDO_RESPONSE  0x580
#define COB_ID_SYNC          0x80
#define COB_ID_BOOTUP        0x700
#define COB_ID_RXPDO         0x200
#define COB_ID_TXPDO         0x180

#define CAN_USE_FD           0      /* 0 = Classic CAN (Disamakan dengan Slave) */

/* STM32G473CB: 128 KB flash */
#define FLASH_TOTAL_SIZE     0x20000U
#define UDP_PERIOD_MS        90U
/* USER CODE END PTD */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN 0 */
/* ---------- Flash (Penyimpanan Node ID) ---------- */
static uint32_t Flash_NodeAddr(void)
{
    uint32_t pageSize = READ_BIT(FLASH->OPTR, FLASH_OPTR_DBANK) ? 2048U : 4096U;
    return FLASH_BASE + FLASH_TOTAL_SIZE - pageSize;
}

uint8_t Flash_ReadNodeId(void)
{
    return *(uint8_t*)Flash_NodeAddr();
}

void Flash_SaveNodeId(uint8_t id)
{
    FLASH_EraseInitTypeDef e = {0};
    uint32_t pageError;

    if (READ_BIT(FLASH->OPTR, FLASH_OPTR_DBANK)) {
        e.Banks = FLASH_BANK_2;
    } else {
        e.Banks = FLASH_BANK_1;
    }
    e.TypeErase = FLASH_TYPEERASE_PAGES;
    e.Page      = 31;
    e.NbPages   = 1;

    uint64_t data = 0xFFFFFFFFFFFFFF00ULL | id;

    HAL_FLASH_Unlock();
    if (HAL_FLASHEx_Erase(&e, &pageError) == HAL_OK) {
        HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, Flash_NodeAddr(), data);
    }
    HAL_FLASH_Lock();
}

/* ---------- Delay Mikrodetik (DWT) ---------- */
void DWT_Delay_Init(void)
{
    if (!(CoreDebug->DEMCR & CoreDebug_DEMCR_TRCENA_Msk))
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

void DWT_Delay_us(volatile uint32_t microseconds)
{
    uint32_t start = DWT->CYCCNT;
    microseconds *= (SystemCoreClock / 1000000);
    while ((DWT->CYCCNT - start) < microseconds);
}

/* ---------- Fungsi CAN ---------- */
void driver_tx_encoder(int16_t speed_data, uint8_t target_id, int16_t enable_data, uint8_t *can_tx_data)
{
    memset(can_tx_data, 0, 8);

    uint16_t magnitude = (speed_data >= 0) ? speed_data : -speed_data;
    if (magnitude > 0x3FFFU) {
        magnitude = 0x3FFFU; // Batasi max 14-bit
    }

    uint8_t high_byte = ((magnitude >> 8) & 0xFFU);
    if (speed_data < 0) {
        high_byte |= 0x40; // Bit 6 = Direction
    }
    if (enable_data & 0x01) {
        high_byte |= 0x80; // Bit 7 = Enable
    }

    can_tx_data[0] = target_id;
    can_tx_data[1] = (uint8_t)(magnitude & 0xFF);
    can_tx_data[2] = high_byte;
}

void send_data_to_canbus(FDCAN_HandleTypeDef *hfdcan, FDCAN_TxHeaderTypeDef *txHeader, uint8_t *cantxdata)
{
    txHeader->Identifier = COB_ID_RXPDO;
    txHeader->DataLength = FDCAN_DLC_BYTES_8;
    HAL_FDCAN_AddMessageToTxFifoQ(hfdcan, txHeader, cantxdata);
}

void send_sync_to_canbus(FDCAN_HandleTypeDef *hfdcan, FDCAN_TxHeaderTypeDef *txHeader)
{
    txHeader->Identifier = COB_ID_SYNC;
    txHeader->DataLength = FDCAN_DLC_BYTES_0;
    HAL_FDCAN_AddMessageToTxFifoQ(hfdcan, txHeader, NULL);
}

static void CAN_InitNode(FDCAN_HandleTypeDef *h, FDCAN_TxHeaderTypeDef *tx)
{
    FDCAN_FilterTypeDef f = {0};
    f.IdType       = FDCAN_STANDARD_ID;
    f.FilterIndex  = 0;
    f.FilterType   = FDCAN_FILTER_MASK;
    f.FilterConfig = FDCAN_FILTER_TO_RXFIFO0;
    f.FilterID1    = 0x000;
    f.FilterID2    = 0x000;

    if (HAL_FDCAN_ConfigFilter(h, &f) != HAL_OK) Error_Handler();

    if (HAL_FDCAN_ConfigGlobalFilter(h, FDCAN_ACCEPT_IN_RX_FIFO0, FDCAN_ACCEPT_IN_RX_FIFO0,
                                     FDCAN_FILTER_REMOTE, FDCAN_FILTER_REMOTE) != HAL_OK) Error_Handler();

    if (HAL_FDCAN_Start(h) != HAL_OK) Error_Handler();
    if (HAL_FDCAN_ActivateNotification(h, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0) != HAL_OK) Error_Handler();

    tx->IdType              = FDCAN_STANDARD_ID;
    tx->TxFrameType         = FDCAN_DATA_FRAME;
    tx->ErrorStateIndicator = FDCAN_ESI_ACTIVE;
#if CAN_USE_FD
    tx->BitRateSwitch       = FDCAN_BRS_ON;
    tx->FDFormat            = FDCAN_FD_CAN;
#else
    tx->BitRateSwitch       = FDCAN_BRS_OFF;
    tx->FDFormat            = FDCAN_CLASSIC_CAN;
#endif
    tx->TxEventFifoControl  = FDCAN_NO_TX_EVENTS;
    tx->MessageMarker       = 0;

    tx->Identifier = COB_ID_BOOTUP + my_node_id;
    tx->DataLength = FDCAN_DLC_BYTES_0;
    HAL_FDCAN_AddMessageToTxFifoQ(h, tx, txData);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* Configure FDCAN Clock Source */
  RCC_PeriphCLKInitTypeDef pclk = {0};
  pclk.PeriphClockSelection = RCC_PERIPHCLK_FDCAN;
  pclk.FdcanClockSelection  = RCC_FDCANCLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&pclk) != HAL_OK) Error_Handler();
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_FDCAN1_Init();
  MX_FDCAN2_Init();
  MX_SPI1_Init();
  MX_TIM1_Init();

  /* USER CODE BEGIN 2 */
  W5500_Init(); // Inisialisasi Ethernet W5500
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  HAL_ADC_Start(&hadc1);
  Buzzer_Beep(100);

  my_node_id = Flash_ReadNodeId();
  if (my_node_id == 0xFF || my_node_id == 0x00) my_node_id = 1;

  DWT_Delay_Init();
  CAN_InitNode(&hfdcan1, &txHeader1);
  CAN_InitNode(&hfdcan2, &txHeader2);

  uint32_t last_udp_tx = HAL_GetTick();
  uint32_t last_can_tx = HAL_GetTick();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* -----------------------------------------------------------------
     * 1. CAN: SIMPAN NODE ID KE FLASH (Request via SDO)
     * ----------------------------------------------------------------- */
    if (save_node_req) {
        save_node_req = 0;
        Flash_SaveNodeId(my_node_id);
    }

    /* -----------------------------------------------------------------
     * 2. TERIMA PAKET UDP DARI PC INSTAN (SETIAP LOOP / REALTIME)
     * Dijalankan tanpa pembatas timer agar tidak terjadi delay penumpukan paket
     * ----------------------------------------------------------------- */
    memset(rx_buf, 0, sizeof(rx_buf));
    W5500_UDP_Receive(rx_buf, 30);

    // Ekstrak data dari header "its"
    for (int i = 0; i <= 19; i++) {
        if (rx_buf[i] == 'i' && rx_buf[i+1] == 't' && rx_buf[i+2] == 's') {

            // 1. Ekstrak enable dari PC (1 Byte)
            enable = (int16_t)rx_buf[i+3];

            // 2. Ekstrak speed dari PC (2 Byte: index i+4 & i+5)
            speed1 = (int16_t)(rx_buf[i+4] | (rx_buf[i+5] << 8));

            // 3. Ekstrak pwmServo / steering dari PC (2 Byte: index i+6 & i+7)
            pwmServo = (int16_t)(rx_buf[i+6] | (rx_buf[i+7] << 8));

            // 4. Ekstrak buzzer dari PC (2 Byte: index i+8 & i+9)
            int16_t buzzer_val = (int16_t)(rx_buf[i+8] | (rx_buf[i+9] << 8));
            if (buzzer_val == 1) {
                Buzzer_Beep(100);
            }

            // Limit speed
            if (speed1 > 2000) {
                speed = 2000;
            } else if (speed1 < -2000) {
                speed = -2000;
            } else {
                speed = speed1;
            }

            break;
        }
    }

    /* -----------------------------------------------------------------
     * 3. CAN: KIRIM PERINTAH MOTOR & SYNC BROADCAST (Setiap 10 ms / 100 Hz)
     * ----------------------------------------------------------------- */
    if ((HAL_GetTick() - last_can_tx) >= 10) {
        last_can_tx = HAL_GetTick();

        driver_tx_encoder(speed, node_id_motor, enable, driver_tx_data);
        send_data_to_canbus(&hfdcan1, &txHeader1, driver_tx_data);

        DWT_Delay_us(100 * my_node_id);

        send_sync_to_canbus(&hfdcan1, &txHeader1);
    }

    /* -----------------------------------------------------------------
     * 4. TELEMETRI: BACA SENSOR & KIRIM KE PC VIA UDP (Setiap 90 ms)
     * ----------------------------------------------------------------- */
    if ((HAL_GetTick() - last_udp_tx) >= UDP_PERIOD_MS) {
        last_udp_tx = HAL_GetTick();

        // Baca Sensor ADC (Tegangan)
        HAL_ADC_Start(&hadc1);
        if (HAL_ADC_PollForConversion(&hadc1, 2) == HAL_OK) { // Lower timeout to 2ms
            adc_raw = HAL_ADC_GetValue(&hadc1);
            voltage = (adc_raw * 3.3f) / 4095.0f;
            voltage_mV = (uint16_t)(voltage * 1000.0f);
        }
        HAL_ADC_Stop(&hadc1);

        // Kirim Telemetri Kembali ke Host/PC
        memset(udp_buf, 0, sizeof(udp_buf));
        memcpy(udp_buf + 0, header, 3);        // Header "its"
        memcpy(udp_buf + 3, &encoder, 2);       // Data 1: Encoder
        memcpy(udp_buf + 5, &button1, 1);       // Tombol 1
        memcpy(udp_buf + 6, &button2, 1);       // Tombol 2

        W5500_UDP_Send(udp_buf, 30);

        // Reset status tombol setelah dikirim
        button1 = 0;
        button2 = 0;
    }

    /* -----------------------------------------------------------------
     * 5. KONTROL HARDWARE (PWM SERVO)
     * ----------------------------------------------------------------- */
    PWM_SetServo(pwmServo);

    // Menghapus HAL_Delay(1) agar loop berputar rapat tanpa delay internal
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs)
{
    if ((RxFifo0ITs & FDCAN_IT_RX_FIFO0_NEW_MESSAGE) == 0) return;

    FDCAN_RxHeaderTypeDef rxHeader;
    uint8_t rxData[8] = {0};

    // Ambil data dari CAN FIFO
    if (HAL_FDCAN_GetRxMessage(hfdcan, FDCAN_RX_FIFO0, &rxHeader, rxData) != HAL_OK) return;

    if (hfdcan->Instance == FDCAN1) {

        /* 1. SDO REQUEST */
        if (rxHeader.Identifier == (uint32_t)(COB_ID_SDO_REQUEST + my_node_id)) {
            if (rxData[0] == 0x50 && rxData[1] == 0x50 && rxData[2] == 0x0D && rxData[3] == 0x00) {
                my_node_id = rxData[4];
            }
            if (rxData[0] == 0x53 && rxData[1] == 0x56 && (rxData[2] + rxData[3]) == 0x00) {
                save_node_req = 1;
            }
        }
        /* 2. Terima Frame TXPDO Balasan dari Slave Motor Driver */
        else if (rxHeader.Identifier == (COB_ID_TXPDO + node_id_motor)) {
            // Ekstrak data 2-Byte Little-Endian langsung dari rxData[0]
            // Byte 0..1: Encoder
            encoder = (int16_t)((uint16_t)rxData[0] | ((uint16_t)rxData[1] << 8));

            // Byte 2..3: Current
            current = (int16_t)((uint16_t)rxData[2] | ((uint16_t)rxData[3] << 8));
        }
    }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    uint32_t current_tick = HAL_GetTick();

    if (GPIO_Pin == GPIO_PIN_5)
    {
        if (current_tick - last_btn1_tick > 150)
        {
            button1 = 1;
            last_btn1_tick = current_tick;
        }
    }
    else if (GPIO_Pin == GPIO_PIN_6)
    {
        if (current_tick - last_btn2_tick > 150)
        {
            button2 = 1;
            last_btn2_tick = current_tick;
        }
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
