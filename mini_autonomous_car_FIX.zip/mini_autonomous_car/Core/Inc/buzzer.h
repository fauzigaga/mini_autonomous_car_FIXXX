/*
 * buzzer.h
 *
 *  Created on: Oct 13, 2026
 *      Author: user
 */

#ifndef INC_BUZZER_H_
#define INC_BUZZER_H_

#include "main.h"

// Sesuaikan PORT dan PIN dengan konfigurasi di STM32CubeMX
#define BUZZER_PORT GPIOB
#define BUZZER_PIN  GPIO_PIN_4

void Buzzer_Init(void);
void Buzzer_On(void);
void Buzzer_Off(void);
void Buzzer_Toggle(void);
void Buzzer_Beep(uint16_t delay_ms);

#endif /* INC_BUZZER_H_ */
