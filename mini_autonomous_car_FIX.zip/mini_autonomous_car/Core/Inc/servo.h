/*
 * servo.h
 *
 *  Created on: Oct 13, 2026
 *      Author: user
 */

#ifndef INC_SERVO_H_
#define INC_SERVO_H_

#include "main.h"
#include <stdint.h>
#include "tim.h"

void PWM_Init(void);
void PWM_SetServo(int16_t pwmServo);

#endif /* INC_SERVO_H_ */
