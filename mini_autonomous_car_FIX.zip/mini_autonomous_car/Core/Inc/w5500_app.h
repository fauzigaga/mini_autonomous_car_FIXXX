/*
 * w5500_app.h
 *
 *  Created on: May 14, 2026
 *      Author: user
 */
#ifndef W5500_APP_H
#define W5500_APP_H

#include "stm32g4xx_hal.h"
#include "wizchip_conf.h"
#include "socket.h"

void W5500_Init(void);
void W5500_UDP_Send(uint8_t *data, uint16_t len);
void W5500_UDP_Receive(uint8_t *data, uint16_t len);
#define UDP_BUF_SIZE 30
#endif
